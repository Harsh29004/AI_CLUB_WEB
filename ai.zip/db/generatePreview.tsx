export const generatePreview = (id: string) => {
  const storageId = process.env.NEXT_PUBLIC_STORAGE_ID;
  const endpoint = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT;
  const projectId = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID;
  if (!storageId) throw new Error("NEXT_PUBLIC_STORAGE_ID is not set");
  if (!endpoint) throw new Error("NEXT_PUBLIC_APPWRITE_ENDPOINT is not set");
  if (!projectId) throw new Error("NEXT_PUBLIC_APPWRITE_PROJECT_ID is not set");

  // Ensure no trailing slash beyond /v1
  const base = endpoint.replace(/\/$/, "");
  // Build preview URL with explicit project query so browser requests include project
  return `${base}/storage/buckets/${storageId}/files/${id}/preview?project=${projectId}`;
};
