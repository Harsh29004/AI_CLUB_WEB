import type { NextApiRequest, NextApiResponse } from 'next';
import { Client, Databases, Storage, ID, Permission, Role } from 'appwrite';

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '10mb',
    },
  },
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { title, summary, content, imageBase64, imageName } = req.body;

    // Validate input
    if (!title || !summary || !content || !imageBase64) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Initialize Appwrite with API key for server-side operations
    const client = new Client();
    client
      .setEndpoint(process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT!)
      .setProject(process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID!);

    const database = new Databases(client);
    const storage = new Storage(client);

    const docId = ID.unique();
    const databaseId = process.env.NEXT_PUBLIC_DATABASE_ID!;
    const collectionId = process.env.NEXT_PUBLIC_COLLECTION_ID!;
    const storageId = process.env.NEXT_PUBLIC_STORAGE_ID!;

    // Create document
    const document = await database.createDocument(
      databaseId,
      collectionId,
      docId,
      {
        title,
        summary,
        content,
      }
    );

    // Convert base64 to blob for file upload
    const base64Data = imageBase64.split(',')[1];
    const binaryData = Buffer.from(base64Data, 'base64');
    
    // Create a file from the buffer (Note: this route is not used by the UI currently)
    const blob = new Blob([new Uint8Array(binaryData)]);
    const file = new File([blob], imageName, { 
      type: imageName.endsWith('.png') ? 'image/png' : 'image/jpeg' 
    });

    // Upload image with document ID
    const fileUpload = await storage.createFile(
      storageId,
      document.$id,
      file,
      [Permission.read(Role.any())]
    );

    return res.status(200).json({
      success: true,
      document,
      file: fileUpload,
    });
  } catch (error: any) {
    console.error('Error creating post:', error);
    return res.status(500).json({
      error: error?.message || 'Failed to create post',
    });
  }
}
