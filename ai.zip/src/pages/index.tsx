"use client";

import Start from "@/components/Starter";

export default function Home() {
  return (
    <main>
      <Start />
    </main>
  );
}
